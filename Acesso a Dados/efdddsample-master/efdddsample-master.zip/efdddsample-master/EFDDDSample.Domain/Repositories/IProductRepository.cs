﻿namespace EFDDDSample.Domain.Repositories
{
    public interface IProductRepository : IRepository<Product>
    {
    }
}
