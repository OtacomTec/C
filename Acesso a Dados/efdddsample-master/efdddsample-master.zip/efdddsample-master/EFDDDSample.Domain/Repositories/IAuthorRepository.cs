﻿namespace EFDDDSample.Domain.Repositories
{
    public interface IAuthorRepository : IRepository<Author>
    {
    }
}
