These are the sample Bounded Contexts for C#.NET from the book "Implementing Domain-Driven Design" by Vaughn Vernon: http://vaughnvernon.co/?page_id=168 

Java Samples: https://github.com/VaughnVernon/IDDD_Samples

NOTE: These are currently an early work in progress. It's
been pushed here so contributors can create pull requests,
etc.

Please don't complain unless you are willing to help ;)

Vaughn