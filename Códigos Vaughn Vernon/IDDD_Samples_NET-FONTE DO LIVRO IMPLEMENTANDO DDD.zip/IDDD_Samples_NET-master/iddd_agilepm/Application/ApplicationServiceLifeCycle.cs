﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SaaSOvation.AgilePM.Application
{
    /// <summary>
    /// TODO: implement
    /// </summary>
    public class ApplicationServiceLifeCycle
    {
        public static void Begin(bool isListening = true)
        {

        }

        public static void Fail(Exception ex = null)
        {

        }

        public static void Success()
        {

        }
    }
}
