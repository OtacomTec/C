﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SaaSOvation.Common.Domain.Model
{
    public interface IIdentity
    {
        string Id { get; }
    }
}
