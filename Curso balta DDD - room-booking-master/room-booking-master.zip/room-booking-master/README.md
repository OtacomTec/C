Este repositório está desatualizado, favor utilizar uma das versões abaixo, já com ASP.NET Core:


Versão Simplificada

https://github.com/andrebaltieri/SimpleRoomBookingCore


Versão Completa

https://github.com/andrebaltieri/RoomBookingCore
