## 1961 - Segurança no ASP.NET Core ##
Neste treinamento vamos entender como ficou a autenticação e a autorização nas aplicações ASP.NET Core

### Conteúdo Programático ###
* Introdução
* Autenticação e Autorização
* Claims e Roles
* Autenticação via Cookies
* Autenticação em Serviços
* Utilizando o Identity

### Assine o Site ###
Faça este e outros treinamentos por apenas R$ 59,90 mensais! Cancele quando quiser e ainda desfrute de treinamentos mensais online, ao vivo e de graça!

http://assine.andrebaltieri.net/
