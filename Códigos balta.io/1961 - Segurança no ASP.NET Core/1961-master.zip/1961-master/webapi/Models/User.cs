﻿namespace AuthBearer.Models
{
    public class User
    {
        public string Password { get; set; }
        public string UserName { get; set; }
    }
}
