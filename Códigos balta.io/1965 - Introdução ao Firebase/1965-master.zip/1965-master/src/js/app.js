var config = {
    apiKey: "AIzaSyCGnOB9DcH-ZxHfd2RYOqMHmnFq1TBGub0",
    authDomain: "curso-fb.firebaseapp.com",
    databaseURL: "https://curso-fb.firebaseio.com",
    storageBucket: "curso-fb.appspot.com",
};
firebase.initializeApp(config);