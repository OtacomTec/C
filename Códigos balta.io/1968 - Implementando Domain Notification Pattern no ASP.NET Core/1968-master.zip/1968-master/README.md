# 1968
Implementando Domain Notification Pattern no ASP.NET Core
