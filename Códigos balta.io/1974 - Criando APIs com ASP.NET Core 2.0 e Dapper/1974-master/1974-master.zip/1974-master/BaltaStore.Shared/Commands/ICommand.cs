namespace BaltaStore.Shared.Commands
{
    public interface ICommand
    {
        bool Valid();
    }
}