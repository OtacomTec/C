namespace BaltaStore.Shared.Commands
{
    public interface ICommandResult
    {
    }
}