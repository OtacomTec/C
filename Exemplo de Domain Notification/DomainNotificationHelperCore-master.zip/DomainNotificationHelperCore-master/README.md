# DomainNotificationHelperCore
Domain Notification Pattern made easy to use, including .NET Core.
