﻿namespace SpaUserControl.Api.Models.Account
{
    public class ResetPasswordModel
    {
        public string Email { get; set; }
    }
}