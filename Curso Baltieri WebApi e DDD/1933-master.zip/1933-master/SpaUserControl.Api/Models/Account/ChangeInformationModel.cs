﻿namespace SpaUserControl.Api.Models.Account
{
    public class ChangeInformationModel
    {
        public string Name { get; set; }
    }
}