# Demo-DDD-Gestor-Prestador-de-Contas
Mini sistema para gerir prestação de contas de funcionários utilizando conceitos do DDD
